### Learn Python

#### The Basics
- [Learn Python the Hard Way](http://learnpythonthehardway.org/book/ex0.html)
- [numpy and scipy tutorial](http://cs231n.github.io/python-numpy-tutorial/)

#### Industry / Conferences
- [pydata / many locations](http://pydata.org/events/)
